require "rspec"
require File.join(File.dirname(__FILE__), "../lib/aloha-ruby-conf.rb")