internallib = require("internallib_v976")

console.log(internallib.command())
