#! /usr/bin/env python
# coding: utf-8

from _advance import DB
from _table import TableDB

__author__ = 'exploitcat'