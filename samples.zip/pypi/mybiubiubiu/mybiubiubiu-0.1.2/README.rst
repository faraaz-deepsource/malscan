mybiubiubiu

Usage
-----

test my function

Installation
------------

pip install mybiubiubiu

Requirements
^^^^^^^^^^^^

Information security awareness

Compatibility
-------------

Licence
-------

Authors
-------

biubiubiu