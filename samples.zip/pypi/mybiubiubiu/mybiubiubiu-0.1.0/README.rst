{{ cookiecutter.package_name }}
{{ cookiecutter.package_name|count * "=" }}


Usage
-----

test my function

Installation
------------

pip install {{ cookiecutter.package_name }}

Requirements
^^^^^^^^^^^^

Information security awareness

Compatibility
-------------

Licence
-------

Authors
-------

`{{ cookiecutter.package_name }}` was written by `{{ cookiecutter.author_name }} <{{ cookiecutter.author_email }}>`_.